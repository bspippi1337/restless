# GitHub Pages (Restless)

This site is deployed from `docs/` via GitHub Actions (see `.github/workflows/pages.yml`).

If you have old/broken workflows from experiments, delete them and keep:
- `.github/workflows/pages.yml`
- `.github/workflows/ci.yml`

Preview locally:
```sh
sh scripts/serve-docs.sh
```
