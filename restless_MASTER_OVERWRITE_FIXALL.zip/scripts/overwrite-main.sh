#!/usr/bin/env sh
set -eu

REPO="${REPO:-bspippi1337/restless}"
BRANCH="${BRANCH:-main}"
REMOTE_URL="${REMOTE_URL:-https://github.com/${REPO}.git}"

echo "[restless] overwrite push to: $REMOTE_URL ($BRANCH)"

if ! command -v git >/dev/null 2>&1; then
  echo "git is required"
  exit 1
fi

# optional: GitHub CLI for auth check
if command -v gh >/dev/null 2>&1; then
  gh auth status >/dev/null 2>&1 || echo "[hint] run: gh auth login"
fi

if [ ! -d .git ]; then
  git init
fi

git config user.name  "${GIT_NAME:-restless-bot}"  >/dev/null
git config user.email "${GIT_EMAIL:-restless-bot@users.noreply.github.com}" >/dev/null

git checkout -B "$BRANCH"

git remote add origin "$REMOTE_URL" 2>/dev/null || git remote set-url origin "$REMOTE_URL"

# make sure we don't accidentally include OS junk
rm -rf .DS_Store 2>/dev/null || true

git add -A
git commit -m "Restless: master overwrite (fixall)" || true

echo "[restless] pushing --force"
git push -u origin "$BRANCH" --force

echo "OK: force-pushed $BRANCH to $REPO"
