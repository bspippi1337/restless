# Restless

Terminal-native API discovery and interaction engine.

## Quickstart

```bash
restless discover openai.com
restless tui
restless doctor
```

See docs/CLI-HELP.md for full command examples.
