#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# Termux-friendly helper:
# 1) unzip this bundle into a folder
# 2) cd into it
# 3) run this script

REPO="${1:-bspippi1337/restless}"
BRANCH="${2:-main}"

if ! command -v git >/dev/null 2>&1; then
  echo "Installing git..."
  pkg update -y
  pkg install -y git
fi

if ! command -v gh >/dev/null 2>&1; then
  echo "Installing gh..."
  pkg install -y gh || true
fi

echo "[restless] Repo: $REPO Branch: $BRANCH"
echo "[restless] If not authenticated: gh auth login"

export REPO="$REPO"
export BRANCH="$BRANCH"
export REMOTE_URL="https://github.com/${REPO}.git"

sh ./scripts/overwrite-main.sh
