# Restless CLI Handbook

Terminal-native API discovery engine.
Domain-first. Evidence-driven.

## Quickstart

restless discover openai.com
restless tui
restless doctor

See full examples inside this file.
